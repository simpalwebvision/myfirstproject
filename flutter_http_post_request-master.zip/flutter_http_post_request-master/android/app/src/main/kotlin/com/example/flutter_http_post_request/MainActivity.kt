package com.example.flutter_http_post_request

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
